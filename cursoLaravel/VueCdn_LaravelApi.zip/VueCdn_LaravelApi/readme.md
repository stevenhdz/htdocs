sudo npm install -g @quasar/cli
sudo npm install -g @vue/cli
sudo npm i -g @vue/cli-init

quasar init app
 cd app
  - quasar dev
  - npx quasar dev