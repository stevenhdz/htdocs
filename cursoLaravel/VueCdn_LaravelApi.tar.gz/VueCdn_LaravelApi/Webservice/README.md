## License

The Laravel framework is open-sourced software licensed under the [MIT license](https://opensource.org/licenses/MIT).

php artisan make:model Articulo
php artisan make:migration create_articulos_table
php artisan make:controller ArticuloController --resource
php artisan migrate
php artisan vendor:publish
 CODE: 10 -> cors
php artisan serve


php artisan migrate:refresh
