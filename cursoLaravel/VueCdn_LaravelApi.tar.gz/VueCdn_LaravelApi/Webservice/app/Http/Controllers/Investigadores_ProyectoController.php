<?php

namespace App\Http\Controllers;

use App\Models\Investigadores;
use App\Models\Investigadores_Proyecto;
use Illuminate\Http\Request;

class Investigadores_ProyectoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $InvestigadoresProyectos = Investigadores_Proyecto::all();
        return $InvestigadoresProyectos;
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $investigadoresProyecto = new Investigadores_Proyecto();
        $investigadoresProyecto->idProyecto = $request->idProyecto;
        $investigadoresProyecto->Cedula = $request->Cedula;
        $investigadoresProyecto->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $investigadoresProyecto = Investigadores_Proyecto::findOrFail($request->idProyecto);
        $investigadoresProyecto = Investigadores_Proyecto::findOrFail($request->Cedula);
        $investigadoresProyecto->save();
        return $investigadoresProyecto;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $investigadoresProyecto = Investigadores_Proyecto::destroy($request->idProyecto);
        $investigadoresProyecto = Investigadores_Proyecto::destroy($request->Cedula);
        return $investigadoresProyecto;
    }
}
