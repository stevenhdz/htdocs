
        <!-- Steven Alexander Hernandez Jimenez
        DESARROLLO WEB CON PHP
        Evidencia: Taller “Uso de formularios para transferencia” -->
      
<!DOCTYPE html>
<html>
<head>
    <title>Actividad Semana 4</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />   
</head>
<?php

require_once("escenario.php");
require_once("accion.php");

if(isset($_REQUEST["Enviar"])){
    $fila = $_POST['fila'];
    $puesto= $_POST['puesto'];
    $accion= $_POST['accion'];
    $escenario=$_POST['list'];

    $count=0;
        for($i=0;$i<5;$i++){
            for($j=0;$j<5;$j++){
                $count=5*$i+$j;
                  $list[$i][$j]=substr($escenario,$count,1);
             }
             $count=0;
        }
        $list=Accion($fila,$puesto,$accion,$list);
        Escenario($list);
}
else if(isset($_REQUEST["Reset"]) || !isset($_REQUEST["Enviar"])){
    $list=array(array("L","L","L","L","L"),array("L","L","L","L","L"),array("L","L","L","L","L"),array("L","L","L","L","L"),array("L","L","L","L","L"));
    Escenario($list);
}
?>
    
<body>
    <table style="margin:auto;">
        <form method="post">
            <input type="text" name="list" value="<?php foreach ($list as $fila) {foreach ($fila as $puesto){echo $puesto;}}?>" style="display:none" />
            <tr>
                <td>Fila:</td>
                <td>
                <input type="text" name="fila">
                </td>
            </tr>
            <tr>
                <td>Puesto: </td>
                <td>
                <input type="text" name="puesto">
                </td>
            </tr>
            <tr>
                <td>Reservar: </td>
                <td>
                    <input type="radio" name="accion" value="R" />
                </td>
            </tr>
            <tr>
                <td>Comprar: </td>
                <td>
                    <input type="radio" name="accion" value="V" />
                </td>
            </tr>
            <tr>
                <td>Liberar: </td>
                <td>
                    <input type="radio" name="accion" value="L" checked="checked" />
                </td>
            </tr>
            <tr>
                <td>
                    <input type="submit" value="Enviar" name="Enviar" />
                </td>
                <td>
                    <input type="submit" value="Borrar" name="Reset" />
                </td>
            </tr>
        </form>
    </table>
</body>