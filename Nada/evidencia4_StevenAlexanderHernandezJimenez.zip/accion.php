<?php
function Accion($fila,$puesto,$accion,$list){
        if($list[$fila-1][$puesto-1]=="L"){
            $list[$fila-1][$puesto-1]=$accion;
        }
        else if($list[$fila-1][$puesto-1]=="V"){
            echo "<script>alert('Esta vendido";
            if($accion=="L"){echo "No se puede liberar";}
            else if($accion=="R"){echo "Esta reservado";}
            else if($accion=="V"){echo "Esta vendido";}
            echo "')";
            echo "</script>'";
        }
        else if($list[$fila-1][$puesto-1]=="R" && $accion=="R"){
            echo "<script>
            alert('Esta reservado');
            </script>'";
        }
        else if($list[$fila-1][$puesto-1]=="R" && $accion!="R"){
            $list[$fila-1][$puesto-1]=$accion;
        }
        return $list;
}
?>