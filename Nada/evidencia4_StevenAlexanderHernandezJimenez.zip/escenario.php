<?php
function Escenario($list){
echo "<table border='1' style='margin:auto;'>";
            echo "<tr>";
            echo "<th colspan='6'>ESCENARIO</th>";
            echo "<tr>";
            echo "<th></th>
                <th>1</th>
                <th>2</th>
                <th>3</th>
                <th>4</th> 
                <th>5</th>
            </tr>";
$i=1;
foreach ($list as $fila) {
    echo "<tr>";
       echo "<th>";
       echo $i;
       echo "</th>";
    foreach ($fila as $silla) {
        echo "<td>";
        echo $silla;
        echo "</td>";
    }
    echo "</tr>";
    $i++;
    }
echo "</table>";
}
?>