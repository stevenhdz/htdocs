<!-- Steven Alexander hernandez Jimenez->
    <!-- Desarrollo Web en PHP-->
<!-- TALLER "USO DE FUNCIONES" -->
<!--
    operaciones artimeticas por medio de una funcion utilizando require_once y $_POST
     -->
<!DOCTYPE html>
<html>

<head>
    <title>operaciones</title>
    <!-- CSS only -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
</head>

<body>
    <form method="POST" action="">
        <h1 class="modal-title">Operaciones</h1>
        <br>
        <div class="container">
            <div class="row">
                <input placeholder="Ingrese numero" class="form-control" type="number" name="numero1">
            </div>
        </div>
        <br>
        <div class="container">
            <div class="row">
                <div class="input-group mb-3">
                    <div class="input-group-prepend">
                        <label class="input-group-text" for="inputGroupSelect01">Operaciones Aritmeticas</label>
                    </div>
                    <select name="operacion">
                        <option value="sumar">Sumar</option>
                        <option value="restar">Restar</option>
                        <option value="multiplicar">Multiplicar</option>
                        <option value="dividir">Dividir</option>
                    </select>
                </div>
            </div>
        </div>
        <br>
        <div class="container">
            <div class="row">
                <input placeholder="Ingrese numero" class="form-control" type="number" name="numero2">
                <br>
                <?php
                require_once 'biblioteca.php';
                ?>
                <br>
                <button class="btn btn-primary" type="submit" name="operar" value="Resultado"> Operar </button>
            </div>
        </div>
    </form>
    <!-- JavaScript Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ygbV9kiqUc6oa4msXn9868pTtWMgiQaeYH7/t7LECLbyPA2x65Kgf80OJFdroafW"
        crossorigin="anonymous"></script>
</body>

</html>