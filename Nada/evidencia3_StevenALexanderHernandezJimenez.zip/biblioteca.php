<?php
if(isset($_POST['operar'])){
function operaciones($num1,$num2,$operaciones){ 
    if( $operaciones=="sumar"){
        $suma=$num1+$num2;
        echo "el resultado es : ".$suma;
    }
        elseif ($operaciones=="restar"){
        $resta=$num1-$num2;
        echo "el resultado es : ".$resta;
    }
    elseif ($operaciones=="multiplicar"){
        $multiplicacion=$num1*$num2;
        echo "el resultado es : ".$multiplicacion;
    }
    elseif ($operaciones=="dividir"){
        $division=$num1/$num2;
        echo "el resultado es : ".$division;
    }
}
echo operaciones($num1=$_POST['numero1'], $num2=$_POST['numero2'],$operaciones=$_POST['operacion']);
}
?>