npm init -y

npm i express body-parser mongoose bcrypt dotenv jsonwebtoken @hapi/joi nodemon cors

configurar el dev y start en scripts